<template>
  <div>
      监控组件
  </div>
</template>

<script>

  export default {
    components:{

    },
    data() {
      return {

      } 
    },
   mounted(){

   },
    methods:{
    },
    watch: {
    }
  }
</script>