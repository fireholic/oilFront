<template>
  <div id="app" class="hostApp">
     <div class="top_nav">

     </div>
      <el-container style="height:100%" >
      <el-aside id="left" style="width:70px;text-align: center;">
          <div :class="{active:checkOne=='NowControl'}" class="icon_css" @click="check()">
          <router-link to="/NowControl">
          <i class="el-icon-pie-chart">
            <div class="on-font" slot="title">实时监控</div>
          </i>
         </router-link>
          </div>
          <div :class="{active:checkOne=='history'}" class="icon_css" @click="check()">
          <router-link to="/History">
          <i class="el-icon-time">
            <div class="on-font" slot="title">历史分析</div>
          </i>
         </router-link>
          </div>
      </el-aside>
       <el-main>
            <router-view/>
       </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: 'App',
  components: {

  },
   created(){
     this.checkOne=this.$router.history.current.name
      console.log(this.checkOne);
  },
  data() {
    return {
     checkOne:""
    };
  },
  methods:{
    check(){
      this.checkOne=this.$router.history.current.name;
      console.log(this.checkOne);
    }
  },
  watch: {

  }
}
</script>
<style lang="scss">
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
#left.div{
  width:70px;
  color: #ffff;
  font-size: 38px;
}
.icons-container{
    margin: 20px;
    height: 85px;
    text-align: center;
    width: 100px;
    float: left;
    font-size: 30px;
    color: #24292e;
    cursor: pointer;
}
.top_nav{
   width:100%;
   height:50px;
   background: url(./assets/daohang.png) no-repeat;
}
.el-main{
  //background: #f4f4f4;
  //background: #27408B;
  margin: 17px 0px 0px 12px;
  padding:0 !important;
  color:#BFEFFF;
}
.el-aside{
    // opacity:1;
    background-color:#151b2b;
}
.el-menu{
  border:0px;
}
.login_bg {
    width: 100%;
    height: 100%;
  }
  .hostApp{
   position: fixed;
   width:100%;
   height:100%;
   //background-color: rgb(48, 65, 86);
   background: url(./assets/bg1.png) no-repeat;
	// background: cover;
  }
#app i{
  color: #ffff;
  font-size: 30px;
}
.icon_css{
  padding: 5px 0px 5px 0px;
}
.el-aside :hover{
  background-color: #2e3550;
}
.active{
 background-color: #2e3550;
}
.on-font{
  margin-top: 10px;
  font-size: 13px;
}
</style>
